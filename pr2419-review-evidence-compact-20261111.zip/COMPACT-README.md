# Compact PR #2419 evidence

Start with [the validation report](current/validation-report.md) and [reproduction instructions](current/README.md).

This ZIP retains every timing sample, per-process status, Catch test log, GPU telemetry sample, reproduction script, configuration, source/binary/data fingerprint, build/test log, and failed probe from the full archive.

Two space reductions are explicit:

- 864 byte-identical result or EXPLAIN TSV copies are represented by aliases to retained files. `result-aliases.json` records each original path, size, SHA256 and canonical copy. All distinct result bytes are retained.
- 312 verbose engine logs from successful benchmark processes are omitted. Their hashes and sizes are in `omitted-files.json`. Their process status, raw samples and Catch logs remain. Failed probes and public-context failures are retained in full.

The original ZIP is unchanged. `source-archive.json` identifies it; `FULL-SHA256SUMS.json` covers every original payload. `SHA256SUMS.json` covers this compact ZIP. Every original payload is accounted for as a retained file, an identical result alias, or an explicitly omitted successful engine log.

After extracting, verify the compact package with:

```bash
python3 verify.py
```

To also restore the duplicate TSV paths from the retained copies:

```bash
python3 verify.py --restore-results
```

The analysis scripts work without restoring TSV copies. The compact package was extracted and verified, all result aliases were restored and checked, and both timing summaries were regenerated and compared with the full archive. No GPU tests were rerun to change these results.
