# PR #2419 validation evidence, 2026-11-11

Validation and measurements are complete within the documented local scope. See [the report](validation-report.md). This directory records new measurements after the rebase; it does not recreate or substantiate missing historical raw measurements.

Base: `976b4b779956c520ad286df7f57b8e5334c22925`. Head: `ffa2795b100939a02923c470f035e2adacf16a05`. Both use the same stable Pixi environment and SM75 compilation on one RTX 2080. See `environment.json` and `stable-env.json`.

## Measurement method

`sql_benchmark.cpp` is an external measurement harness linked against each checkout's own C++ test objects and engine. Repository code, test defaults, and budgets are unchanged. `build_harness.py` records the exact compilation/link commands and binary hashes.

Each process runs one workload, first through DuckDB CPU with GPU execution disabled, then two GPU warmups and measured repetitions. CPU execution counters must show zero GPU work; every GPU repetition must show exactly one execution, no planning/runtime fallback, matching types and matching results. Integer/decimal/string/null values match exactly; only FLOAT/DOUBLE results use a relative/absolute tolerance of `1e-9`. Rows are compared as sorted multisets; this harness does not assert `ORDER BY` output ordering. Results are compared outside the timing boundary. Timing covers the SQL query call through materialized result return; CPU time and process peak RSS are also recorded. RSS is not a measurement of active host buffers or GPU allocator peak.

SF30 covers native and Parquet Q1–Q22, five measured repetitions per process. Four synthetic scan workloads use 30 repetitions: plain Parquet, Iceberg field mapping, partial range/null pushdown, and field mapping with a range/null predicate. The Iceberg table has an old file with `px/pv INT32`, and a new file with `x/v INT64`; field IDs preserve identity across renaming and promotion. All data generation scripts and file hashes are retained. The plain partial-pushdown workload combines a safe range predicate with `IS NULL`, which stays in the post-decode predicate; see the recorded `EXPLAIN` and `parquet_scan_core.cpp` at the recorded revision. Mapped files disable reader row filtering and retain post-decode filtering, so the mapped-plus-filter workload is not claimed to exercise reader row filtering on those files.

The fixed process order for every workload is base → head → base control, then head → base → head control. Processes use CPU affinity 0–15, the same config, data and dependencies; GPU clock, utilization, memory and temperature are sampled. Builds and other GPU tests must finish before formal measurements. Pilot runs are excluded from performance statistics. `benchmark.yaml` sets the benchmark GPU fraction to 0.70 and host capacity to 32 GB; DuckDB uses eight CPU threads. These overrides apply only to the external benchmark. The GPU also drives the desktop; clocks are not locked and OS caches are not dropped. Two warmups do not imply a fully GPU-resident dataset.

This run measures the production SQL paths. It does not measure direct materializer calls, replacement decoders, or the first import of canonical lineage. Its results apply to the current base/head pair; earlier ratios are not reused.

## Reproduction

Commands run from an activated environment via `pixi run`; `run.py` logs each command, exit status, source commit, source diff hash and local build overrides. Use two clean checkouts at the commits above, initialize submodules, and build both with the same Pixi dependencies and `-DCMAKE_CUDA_ARCHITECTURES=75-real` (adapt only the architecture for another GPU).

1. Build `test_datasets/tpchgen-rs` at `cdcf74def0072f94bf1886667e8d2ac51feb8721` (the generator checkout recorded in this run), then generate SF30 with `test/tpch_performance/generate_tpch_data.sh 30 --format parquet --output <evidence>/data/tpch_sf30 --jobs 4`.
2. Run `prepare_data.py`, then `prepare_mapping.py`. The scripts live with their output directory and currently use `/nv/cpp/sirius` as the source checkout; adjust that source path when reproducing elsewhere. Generated SQL contains the local absolute dataset paths.
3. Run `build_harness.py <base-checkout> base` and `build_harness.py <head-checkout> head`.
4. Run `paired.py pilot`, review all checks, then `paired.py full`. The runner also uses `/nv/cpp/sirius` as its working directory; adjust that path for another host.
5. Summarize with `summarize.py`. For a slow candidate, run `paired.py retest parquet:q1` (substitute the source/query), then `summarize.py long-retest`. The extended run uses 20 measured repetitions per process with the same order and controls.

Generated Iceberg snapshot IDs and metadata timestamps can change across regenerations; `prepare_mapping.py` writes queries for its actual snapshot. The data manifests identify the precise inputs measured here, rather than requiring regenerated metadata to be byte-identical.

## Boundaries and retained failures

- Nightly is compile-only; the earlier successful build is archived separately. Two-GPU and ARM64 validation are not claimed locally.
- The added public-context stage has the same three failures on main and head, each allocating 7,754,258,841 bytes on an 8 GiB display GPU with about 1 GiB already occupied. Both report 2 passed / 3 failed. This local hardware limitation is not counted as a pass. No test expectation or resource budget was weakened.
- `initial-probes/plain-schema-head` and `initial-probes/scan-mapped-plain-schema-probe-r0-base` retain the direct Parquet `schema=` rename/promotion probe. Both revisions reject it with `Parquet pruning column 'x' has unqualified type drift`, then return correct CPU results via fallback. The strict GPU check rejects both measurements. Formal mapped measurements use the production Iceberg field-ID mapping route instead; no engine acceptance rule was changed.
- Initial harness compilation and fixture-generation failures are preserved in their logs. They are harness setup failures, not successful measurements.

The report and proposed review reply accompany the archive. Hosted CI and the public-context hardware limitation remain open. Review replies require the user's review before publication.
