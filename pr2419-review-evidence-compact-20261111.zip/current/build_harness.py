import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parent
repo, label = Path(sys.argv[1]), sys.argv[2]
build = repo / 'build/release'
entries = json.loads((build/'compile_commands.json').read_text())
entry = next(e for e in entries if e['file'].endswith('/test/cpp/scan/test_parquet_schema_mapping.cpp'))
command = shlex.split(entry['command'])
object_file = root/(label+'-sql_benchmark.o')
command[command.index('-o')+1] = str(object_file)
command[command.index('-c')+1] = str(root/'sql_benchmark.cpp')
subprocess.run(command, cwd=entry['directory'], check=True)
commands = subprocess.check_output(['ninja','-t','commands','sirius_unittest'], cwd=build, text=True).splitlines()
link = next(line for line in reversed(commands) if ' -o test/cpp/sirius_unittest ' in line)
# CMake wraps the compiler invocation in ': && ... && :'.
link = link.removeprefix(': && ').removesuffix(' && :')
args = shlex.split(link)
binary = root/(label+'-sql-benchmark')
args[args.index('-o')+1] = str(binary)
args.insert(args.index('-o'), str(object_file))
subprocess.run(args, cwd=build, check=True)
(root/(label+'-harness-build.json')).write_text(json.dumps(dict(repo=str(repo), compile=command, link=args, source_sha256=hashlib.sha256((root/'sql_benchmark.cpp').read_bytes()).hexdigest(), binary_sha256=hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()), indent=2)+'\n')
print(binary)
