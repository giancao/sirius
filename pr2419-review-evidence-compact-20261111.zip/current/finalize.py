import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess

root=Path(__file__).resolve().parent
repos={'head':Path('/nv/cpp/sirius'),'base':Path('/nv/cpp/sirius/.codex/pr2419-performance-main-20261111')}
expected={'head':'ffa2795b100939a02923c470f035e2adacf16a05','base':'976b4b779956c520ad286df7f57b8e5334c22925'}
result={'sources':{},'binaries':{},'data_files_verified':0}
for label,repo in repos.items():
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    status=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
    assert sha==expected[label] and not status,(label,sha,status)
    result['sources'][label]=sha
    info=json.loads((root/(label+'-harness-build.json')).read_text())
    assert hashlib.file_digest((root/(label+'-sql-benchmark')).open('rb'),'sha256').hexdigest()==info['binary_sha256']
    assert hashlib.sha256((root/'sql_benchmark.cpp').read_bytes()).hexdigest()==info['source_sha256']
    result['binaries'][label]=[]
    for rel in ('build/release/libsirius.so.0.0.0','build/release/libsirius_core.a','build/release/test/cpp/sirius_unittest','sirius-duckdb/build/release/extension/sirius/sirius.duckdb_extension'):
        path=repo/rel
        result['binaries'][label].append(dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()))
summary=json.loads((root/'comparison.json').read_text())
assert summary['completed_workloads']==48 and summary['completed_processes']==288
assert summary['measured_samples']==2040
result['measurements']=dict(workloads=48,processes=288,measured_samples=2040,warmups=576)
long_summary=json.loads((root/'long-retest-comparison.json').read_text())
assert any(row['source']=='parquet' and row['query']=='q1' for row in long_summary['rows'])
assert long_summary['completed_processes']==6*long_summary['completed_workloads']
assert long_summary['measured_samples']==120*long_summary['completed_workloads']
result['long_retest']=dict(workloads=long_summary['completed_workloads'],processes=long_summary['completed_processes'],measured_samples=long_summary['measured_samples'],warmups=2*long_summary['completed_processes'])
for series in ('paired','long-retest'):
    for path in (root/series).glob('*/status.json'):
        status=json.loads(path.read_text())
        assert status['exit_code']==0 and status['verified_gpu']
        build=json.loads((root/(status['label']+'-harness-build.json')).read_text())
        assert status['binary_sha256']==build['binary_sha256']
        assert status['harness_source_sha256']==build['source_sha256']
        for key,env_key in (('query_sha256','EVIDENCE_QUERY'),('setup_sha256','EVIDENCE_SETUP')):
            assert hashlib.sha256(Path(status['environment'][env_key]).read_bytes()).hexdigest()==status[key]
        rows=list(csv.DictReader(path.with_name('samples.csv').open()))
        count=int(status['environment']['EVIDENCE_ITERATIONS'])
        assert len(rows)==count+2==status['sample_count']
        assert sum(row['warmup']=='0' for row in rows)==count==status['measured_count']
        assert all(row['gpu_executions']=='1' and row['plan_fallbacks']=='0' and row['runtime_fallbacks']=='0' for row in rows)
for manifest in ('data-manifest.json','mapping-data-manifest.json'):
    files=json.loads((root/manifest).read_text())
    if isinstance(files,dict):files=files['files']
    for info in files:
        path=root/info['path']
        assert path.stat().st_size==info['bytes']
        assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==info['sha256'],str(path)
        result['data_files_verified']+=1
head_context=(root/'stable-extra-stages.log').read_text()
base_context=(root/'base-context.log').read_text()
failures=lambda text:re.findall(r'test_public_context.cpp:(\d+): FAILED:',text)
assert failures(head_context)==failures(base_context)==['83','98','117']
assert head_context.count('failed to allocate 7754258841')==base_context.count('failed to allocate 7754258841')==3
result['context_limitation']={'main_and_head':'2 passed / 3 failed','same_failures':True,'allocation_bytes':7754258841,'counted_as_pass':False}
for name in ('head-stable-build','base-stable-build','stable-fault-late','stable-arrow','stable-arrow-all','paired-measurements','long-retest'):
    status=json.loads((root/(name+'.json')).read_text())
    assert status['exit_code']==0,(name,status)
result['repository_code_changed']=False
result['nightly_runtime_run']=False
result['local_multi_gpu_run']=False
(root/'final-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='binaries'}))
