import hashlib
import json
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
previous=root.parent/'pr2419-rebase-20261111'
archive=root.parent/'pr2419-review-evidence-20261111.zip'
assert (root/'final-check.json').exists()
assert 'PERFORMANCE_INTERPRETATION_PENDING' not in (root/'validation-report.md').read_text()
entries=[]
def include(path,arc):
    entries.append((path,arc))
for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue
    rel=path.relative_to(root)
    if rel.parts[0] in ('data','__pycache__') or path.suffix in ('.o','.zip') or path.name in ('base-sql-benchmark','head-sql-benchmark','SHA256SUMS.json','archive-result.json'):
        continue
    if path.suffix not in ('.md','.py','.cpp','.yaml','.json','.csv','.tsv','.sql','.log','.txt'):
        continue
    include(path,'current/'+str(rel))
for name in ('report.md','final-check.json','format-source-proof.json','clang-compiler-proof.json','stable-artifacts.json','clang-artifacts.json','nightly-artifacts.json','status.json','pre-commit.log','stable-tests.log','stable-s3.log','clang-build.log','nightly-build.log','reviewed-source.json','scan-coverage.json','push-result.json','pre-push-workflow.md'):
    include(previous/name,'pre-push/'+name)
manifest=[]
for path,arc in entries:
    manifest.append(dict(path=arc,bytes=path.stat().st_size,sha256=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()))
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,arc in entries:
        z.write(path,arc)
    z.writestr('SHA256SUMS.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in manifest:
        assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
record=dict(archive=str(archive),bytes=archive.stat().st_size,files=len(manifest),sha256=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest())
(root/'archive-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
