import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
mode = sys.argv[1] if len(sys.argv)>1 else 'full'
run_root = root/('pilot' if mode == 'pilot' else 'paired')
if mode == 'probe':
    run_root = root/'initial-probes'
if mode == 'retest':
    run_root = root/'long-retest'
run_root.mkdir(exist_ok=True)
workloads = [('scan', name, 30) for name in ('plain','mapped','partial','mapped_partial')]
workloads += [(source, 'q'+str(i), 5) for source in ('parquet','native') for i in range(1,23)]
if mode == 'pilot':
    workloads = [('scan',name,2) for name in ('plain','mapped','partial','mapped_partial')] + [('parquet','q6',1),('native','q6',1)]
    if os.getenv('EVIDENCE_PILOT_WORKLOADS'):
        allowed = os.environ['EVIDENCE_PILOT_WORKLOADS'].split(',')
        workloads = [item for item in workloads if item[0]+'-'+item[1] in allowed]
schedule = [('base',0,False),('head',0,False)] if mode == 'pilot' else [('base',0,False),('head',0,False),('base',0,True),('head',1,False),('base',1,False),('head',1,True)]
if mode == 'probe':
    workloads = [('scan','mapped-plain-schema-probe',1)]
    schedule = [('base',0,False)]
if mode == 'retest':
    assert sys.argv[2:], 'Specify source:query pairs for retesting'
    workloads = [(item.split(':')[0],item.split(':')[1],20) for item in sys.argv[2:]]
if mode == 'pilot' and os.getenv('EVIDENCE_PILOT_LABEL'):
    schedule = [item for item in schedule if item[0] == os.environ['EVIDENCE_PILOT_LABEL']]
builds = {}
for source, query, iterations in workloads:
    for label, round_id, control in schedule:
        name = f'{source}-{query}-r{round_id}-{label}'+('-control' if control else '')
        out = run_root/name
        if (out/'status.json').exists():
            status=json.loads((out/'status.json').read_text())
            if status.get('exit_code') == 0:
                continue
            raise SystemExit('Prior failed run must be reviewed: '+name)
        out.mkdir(exist_ok=True)
        if label not in builds:
            builds[label] = json.loads((root/(label+'-harness-build.json')).read_text())
            assert hashlib.file_digest((root/(label+'-sql-benchmark')).open('rb'),'sha256').hexdigest() == builds[label]['binary_sha256']
            assert hashlib.sha256((root/'sql_benchmark.cpp').read_bytes()).hexdigest() == builds[label]['source_sha256']
        env = os.environ.copy()
        env.update(EVIDENCE_SETUP=str(root/'queries'/f'{source}-setup.sql'), EVIDENCE_QUERY=str(root/'queries'/f'{query}.sql'), EVIDENCE_OUTPUT=str(out/'samples'), EVIDENCE_ITERATIONS=str(iterations), SIRIUS_TEST_INTEGRATION_CONFIG=str(root/'benchmark.yaml'), SIRIUS_TEST_SHARED_CONFIG_OVERRIDE=str(root/'benchmark.yaml'), SIRIUS_TEST_LOG_DIR=str(out/'engine-log'))
        cmd = ['taskset','-c','0-15',str(root/(label+'-sql-benchmark')),'[pr2419_evidence]','--order','decl']
        info = dict(name=name,source=source,query=query,label=label,round=round_id,control=control,command=cmd,environment={k:v for k,v in env.items() if k.startswith('EVIDENCE_') or k.startswith('SIRIUS_TEST_')},started_utc=datetime.datetime.now(datetime.UTC).isoformat())
        info.update(binary_sha256=builds[label]['binary_sha256'], harness_source_sha256=builds[label]['source_sha256'], query_sha256=hashlib.sha256(Path(env['EVIDENCE_QUERY']).read_bytes()).hexdigest(), setup_sha256=hashlib.sha256(Path(env['EVIDENCE_SETUP']).read_bytes()).hexdigest())
        (out/'status.json').write_text(json.dumps(info,indent=2)+'\n')
        print('START',name,flush=True)
        start=time.time()
        with (out/'gpu.csv').open('w') as gpu_log, (out/'run.log').open('w') as log:
            monitor=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,name,memory.used,utilization.gpu,clocks.sm,clocks.mem,temperature.gpu,power.draw','--format=csv','--loop-ms=1000'],stdout=gpu_log,stderr=subprocess.STDOUT)
            try:
                result=subprocess.run(cmd,env=env,cwd='/nv/cpp/sirius',stdout=log,stderr=subprocess.STDOUT,timeout=1800)
                info['exit_code']=result.returncode
            except subprocess.TimeoutExpired:
                info['exit_code']=124
            finally:
                monitor.terminate()
                monitor.wait(timeout=10)
        info['elapsed_seconds']=time.time()-start
        samples_file=out/'samples.csv'
        records=list(csv.DictReader(samples_file.open())) if samples_file.exists() else []
        info['sample_count']=len(records)
        info['measured_count']=sum(row['warmup']=='0' for row in records)
        info['verified_gpu']=all(row['gpu_executions']=='1' and row['plan_fallbacks']=='0' and row['runtime_fallbacks']=='0' for row in records)
        if info['exit_code']==0 and (len(records)!=iterations+2 or not info['verified_gpu']):
            info['exit_code']=125
        (out/'status.json').write_text(json.dumps(info,indent=2)+'\n')
        print('DONE',name,'exit',info['exit_code'],'seconds',round(info['elapsed_seconds'],2),flush=True)
        if info['exit_code']:
            raise SystemExit(info['exit_code'])
