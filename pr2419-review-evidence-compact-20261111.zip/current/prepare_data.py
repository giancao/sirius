import hashlib
import json
from pathlib import Path
import shutil
import duckdb

root = Path(__file__).resolve().parent
repo = Path('/nv/cpp/sirius')
data = root/'data'
queries = root/'queries'
queries.mkdir(exist_ok=True)
tables = ['region','nation','supplier','customer','part','partsupp','orders','lineitem']
native = data/'tpch_sf30.duckdb'
if native.exists():
    raise SystemExit('Refusing to overwrite native fixture')
con = duckdb.connect(str(native))
con.execute("SET threads=4; SET memory_limit='8GB'")
for table in tables:
    parquet = data/'tpch_sf30'/table/'*.parquet'
    con.execute(f"CREATE TABLE {table} AS SELECT * FROM read_parquet('{parquet}')")
    print(table, con.execute(f'SELECT count(*) FROM {table}').fetchone()[0], flush=True)
con.execute('CHECKPOINT')
con.close()
(queries/'native-setup.sql').write_text(f"ATTACH '{native}' AS perf (READ_ONLY); USE perf;")
(queries/'parquet-setup.sql').write_text('\n'.join(f"CREATE VIEW {table} AS SELECT * FROM read_parquet('{data/'tpch_sf30'/table/'*.parquet'}');" for table in tables))
for i in range(1,23):
    shutil.copyfile(repo/f'test/tpch_performance/tpch_queries/orig/q{i}.sql', queries/f'q{i}.sql')
con = duckdb.connect()
con.execute('SET threads=4')
scan = data/'scan.parquet'
con.execute(f"COPY (SELECT i::INTEGER AS px, CASE WHEN i%3=0 THEN NULL ELSE i::INTEGER END AS pv FROM range(2000000) t(i)) TO '{scan}' (FORMAT PARQUET, ROW_GROUP_SIZE 122880, COMPRESSION ZSTD, FIELD_IDS {{px:10,pv:11}})")
plain = f"read_parquet('{scan}', hive_partitioning=false)"
mapped = f"read_parquet('{scan}', hive_partitioning=false, schema=map {{10: {{name:'x',type:'BIGINT',default_value:NULL}},11: {{name:'v',type:'BIGINT',default_value:NULL}}}})"
(queries/'scan-setup.sql').write_text('SELECT 1;')
for name, source, x, v, partial in [('plain',plain,'px','pv',False),('mapped',mapped,'x','v',False),('partial',plain,'px','pv',True),('mapped_partial',mapped,'x','v',True)]:
    query = f'SELECT {x}%32 AS bucket, count(*) AS n, sum({x}) AS total FROM {source} WHERE {x}>1000000'
    if partial:
        query += f' AND {v} IS NULL'
    query += ' GROUP BY bucket ORDER BY bucket;\n'
    (queries/(name+'.sql')).write_text(query)
    print(name, con.execute(query).fetchall()[:2], flush=True)
con.close()
files = []
for path in sorted(data.rglob('*')):
    if path.is_file():
        files.append(dict(path=str(path.relative_to(root)), bytes=path.stat().st_size, sha256=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()))
(root/'data-manifest.json').write_text(json.dumps(dict(scale_factor=30, generator='repository tpchgen-rs', native_import='DuckDB '+duckdb.__version__+' CTAS from the same parquet dataset', files=files), indent=2)+'\n')
