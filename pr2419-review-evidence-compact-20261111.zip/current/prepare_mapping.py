import json
from pathlib import Path
import pyarrow as pa
import pyarrow.compute as pc
from pyiceberg.catalog.sql import SqlCatalog
from pyiceberg.types import LongType
from sqlalchemy.engine import URL

root=Path(__file__).resolve().parent
warehouse=root/'data'/'mapping_iceberg'
warehouse.mkdir()
catalog=SqlCatalog('evidence',uri=URL.create('sqlite',database=str(warehouse/'catalog.sqlite')).render_as_string(),warehouse=str(warehouse))
catalog.create_namespace('bench')
table=catalog.create_table(('bench','mapped'),schema=pa.schema([pa.field('px',pa.int32()),pa.field('pv',pa.int32())]),location=str(warehouse/'mapped'),properties={'format-version':'2'})
ids=pa.array(range(1000000),type=pa.int32())
nulls=pa.array([None if i%3==0 else i for i in range(1000000)],type=pa.int32())
table.append(pa.table({'px':ids,'pv':nulls}))
with table.update_schema() as update:
    update.update_column('px',field_type=LongType()).update_column('pv',field_type=LongType()).rename_column('px','x').rename_column('pv','v')
ids=pa.array(range(1000000,2000000),type=pa.int64())
nulls=pa.array([None if i%3==0 else i for i in range(1000000,2000000)],type=pa.int64())
table.append(pa.table({'x':ids,'v':nulls}))
snapshot=table.current_snapshot()
metadata=Path(table.metadata_location)
(metadata.parent/'version-hint.text').write_text(metadata.name.removesuffix('.metadata.json'))
source=f"iceberg_scan('{warehouse/'mapped'}', snapshot_from_id={snapshot.snapshot_id})"
queries=root/'queries'
for name, suffix in [('mapped',''),('mapped_partial',' WHERE x>500000 AND v IS NULL')]:
    old=queries/(name+'.sql')
    old.rename(queries/(name+'-plain-schema-probe.sql'))
    old.write_text(f'SELECT x%32 AS bucket, count(*) AS n, sum(x) AS total FROM {source}{suffix} GROUP BY bucket ORDER BY bucket;\n')
(queries/'scan-setup.sql').write_text('LOAD iceberg; SET unsafe_enable_version_guessing=true;')
(root/'mapping-fixture.json').write_text(json.dumps(dict(snapshot_id=snapshot.snapshot_id,metadata=table.metadata_location,schema=str(table.schema()),files=[dict(path=task.file.file_path,rows=task.file.record_count) for task in table.scan().plan_files()],meaning='old file: px/pv INT32; new file: x/v INT64; shared field IDs, promoted current schema'),indent=2)+'\n')
catalog.engine.dispose()
print(source,flush=True)
