CREATE VIEW region AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/region/*.parquet');
CREATE VIEW nation AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/nation/*.parquet');
CREATE VIEW supplier AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/supplier/*.parquet');
CREATE VIEW customer AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/customer/*.parquet');
CREATE VIEW part AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/part/*.parquet');
CREATE VIEW partsupp AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/partsupp/*.parquet');
CREATE VIEW orders AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/orders/*.parquet');
CREATE VIEW lineitem AS SELECT * FROM read_parquet('/nv/cpp/workshop/sirius-ssw/1796/r4b-artifacts/pr2419-evidence-20261111/data/tpch_sf30/lineitem/*.parquet');