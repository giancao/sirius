Rebased onto `976b4b77` and resolved the I/O migration conflicts. Stable/Clang/nightly builds and local ordinary, S3 and Arrow checks passed; nightly was compile-only.

The attached archive contains fresh SF30 native/Parquet and mapped/partial-pushdown measurements, raw samples, reproduction steps and same-version controls. The two initial slowdowns did not persist in extended runs.

Hosted Test/Check still await approval. Three public-context cases hit the same VRAM limit on main and head.
