import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
name, repo, *command = sys.argv[1:]
log = root / (name + '.log')
if log.exists():
    raise SystemExit('Refusing to overwrite existing log: ' + str(log))
env = os.environ.copy()
env['CMAKE_BUILD_PARALLEL_LEVEL'] = '10'
env['SIRIUS_CMAKE_FLAGS'] = '-DCMAKE_C_COMPILER_LAUNCHER=sccache -DCMAKE_CXX_COMPILER_LAUNCHER=sccache -DCMAKE_CUDA_COMPILER_LAUNCHER=sccache -DCMAKE_LINKER_TYPE=MOLD -DCMAKE_CUDA_ARCHITECTURES=75-real'
started = time.time()
record = dict(name=name, cwd=repo, command=command, started_utc=datetime.datetime.now(datetime.UTC).isoformat(), head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(), environment_overrides={k: env[k] for k in ('CMAKE_BUILD_PARALLEL_LEVEL', 'SIRIUS_CMAKE_FLAGS')})
(root / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
with log.open('w') as output:
    result = subprocess.run(command, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode, elapsed_seconds=time.time()-started, source_diff_sha256=hashlib.sha256(subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=repo)).hexdigest())
(root / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(name, 'exit', result.returncode, flush=True)
raise SystemExit(result.returncode)
