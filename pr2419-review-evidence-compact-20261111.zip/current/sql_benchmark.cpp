#include <utils/gpu_execution_fixture.hpp>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <sys/resource.h>

namespace {
std::string required_env(char const* name) {
  auto value = std::getenv(name);
  REQUIRE(value != nullptr);
  return value;
}
std::string read_file(std::string const& path) {
  std::ifstream in(path);
  REQUIRE(in.good());
  return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
}
using rows_t = std::vector<std::vector<std::string>>;
void save_rows(std::string const& path, rows_t const& rows) {
  std::ofstream out(path);
  REQUIRE(out.good());
  for (auto const& row : rows) {
    for (std::size_t i = 0; i < row.size(); ++i) out << (i ? "\t" : "") << std::quoted(row[i]);
    out << '\n';
  }
}
double cpu_ms() {
  rusage usage{};
  REQUIRE(getrusage(RUSAGE_SELF, &usage) == 0);
  return 1000.0 * (usage.ru_utime.tv_sec + usage.ru_stime.tv_sec)
    + 0.001 * (usage.ru_utime.tv_usec + usage.ru_stime.tv_usec);
}
}

TEST_CASE_METHOD(sirius::test::GpuExecutionFixture,
                 "PR2419 reproducible SQL performance witness",
                 "[integration][pr2419_evidence]") {
  auto const setup = read_file(required_env("EVIDENCE_SETUP"));
  auto const query = read_file(required_env("EVIDENCE_QUERY"));
  auto const output = required_env("EVIDENCE_OUTPUT");
  auto const iterations = std::stoi(required_env("EVIDENCE_ITERATIONS"));
  run_ok("SET gpu_execution=false");
  run_ok("SET threads=8");
  run_ok(setup);
  auto const before_cpu = sirius::test::get_transparent_execution_stats(*con);
  auto expected = con->Query(query);
  REQUIRE(expected);
  INFO((expected->HasError() ? expected->GetError() : "CPU oracle succeeded"));
  REQUIRE_FALSE(expected->HasError());
  sirius::test::require_transparent_execution_delta(before_cpu, sirius::test::get_transparent_execution_stats(*con), 0, 0, 0);
  auto expected_rows = collect_rows(*expected);
  save_rows(output + ".expected.tsv", expected_rows);
  auto explain = con->Query("EXPLAIN " + query);
  REQUIRE(explain);
  REQUIRE_FALSE(explain->HasError());
  save_rows(output + ".explain.tsv", collect_rows(*explain));
  run_ok("SET gpu_execution=true");
  std::ofstream samples(output + ".csv");
  REQUIRE(samples.good());
  samples << "iteration,warmup,elapsed_ms,cpu_ms,rows,gpu_executions,plan_fallbacks,runtime_fallbacks,maxrss_kib\n";
  samples << std::setprecision(12);
  for (int i = -2; i < iterations; ++i) {
    CAPTURE(i, query);
    auto const before = sirius::test::get_transparent_execution_stats(*con);
    auto const cpu_start = cpu_ms();
    auto const start = std::chrono::steady_clock::now();
    auto actual = con->Query(query);
    auto const elapsed = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    auto const cpu_elapsed = cpu_ms() - cpu_start;
    REQUIRE(actual);
    INFO((actual->HasError() ? actual->GetError() : "GPU query succeeded"));
    REQUIRE_FALSE(actual->HasError());
    auto const after = sirius::test::get_transparent_execution_stats(*con);
    sirius::test::require_transparent_execution_delta(before, after, 1, 0, 1);
    REQUIRE(actual->GetTypes() == expected->GetTypes());
    auto actual_rows = collect_rows(*actual);
    REQUIRE(actual_rows.size() == expected_rows.size());
    for (std::size_t row = 0; row < expected_rows.size(); ++row) {
      REQUIRE(actual_rows[row].size() == expected_rows[row].size());
      for (std::size_t col = 0; col < expected_rows[row].size(); ++col) {
        auto const type = expected->GetTypes()[col].id();
        double const tolerance = (type == duckdb::LogicalTypeId::FLOAT || type == duckdb::LogicalTypeId::DOUBLE) ? 1e-9 : 0;
        CAPTURE(row, col, actual_rows[row][col], expected_rows[row][col]);
        REQUIRE(cells_equal(actual_rows[row][col], expected_rows[row][col], tolerance));
      }
    }
    if (i == iterations - 1) save_rows(output + ".actual.tsv", actual_rows);
    rusage usage{};
    REQUIRE(getrusage(RUSAGE_SELF, &usage) == 0);
    samples << i << ',' << (i < 0) << ',' << elapsed << ',' << cpu_elapsed << ',' << actual_rows.size() << ','
      << after.executions-before.executions << ',' << after.fallbacks-before.fallbacks << ','
      << after.runtime_fallbacks-before.runtime_fallbacks << ',' << usage.ru_maxrss << '\n';
    samples.flush();
  }
}
