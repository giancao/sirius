import csv
import json
from pathlib import Path
import statistics
import sys

root=Path(__file__).resolve().parent
series=sys.argv[1] if len(sys.argv)>1 else 'paired'
prefix='comparison' if series=='paired' else series+'-comparison'
groups={}
for path in sorted((root/series).glob('*/status.json')):
    status=json.loads(path.read_text())
    if 'exit_code' not in status:
        continue
    if status.get('exit_code') != 0:
        raise SystemExit('Incomplete or failed measurement: '+str(path))
    records=list(csv.DictReader(path.with_name('samples.csv').open()))
    assert len(records)==status['sample_count']
    assert all(r['gpu_executions']=='1' and r['plan_fallbacks']=='0' and r['runtime_fallbacks']=='0' for r in records)
    values=[float(r['elapsed_ms']) for r in records if r['warmup']=='0']
    assert len(values)==status['measured_count']
    key=(status['source'],status['query'])
    groups.setdefault(key,[]).append(dict(**status,values=values,median_ms=statistics.median(values)))
rows=[]
for (source,query),runs in groups.items():
    if len(runs)!=6:
        continue
    def measured(label,control=False):
        return [r for r in runs if r['label']==label and r['control']==control]
    base=statistics.median([t for r in measured('base') for t in r['values']])
    head=statistics.median([t for r in measured('head') for t in r['values']])
    pairs=[]
    for i in (0,1):
        a=next(r['median_ms'] for r in measured('base') if r['round']==i)
        b=next(r['median_ms'] for r in measured('head') if r['round']==i)
        pairs.append(b/a)
    ac=measured('base',True)[0]['median_ms']/next(r['median_ms'] for r in measured('base') if r['round']==0)
    bc=measured('head',True)[0]['median_ms']/next(r['median_ms'] for r in measured('head') if r['round']==1)
    row=dict(source=source,query=query,base_ms=base,head_ms=head,ratio=head/base,round0_ratio=pairs[0],round1_ratio=pairs[1],base_control_ratio=ac,head_control_ratio=bc,measured_per_version=sum(len(r['values']) for r in measured('base')))
    rows.append(row)
if rows:
    with (root/(prefix+'.csv')).open('w') as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)
summary=dict(completed_workloads=len(rows),expected_workloads=48 if series=='paired' else None,completed_processes=sum(len(v) for v in groups.values()),measured_samples=sum(len(r['values']) for runs in groups.values() for r in runs),rows=rows)
(root/(prefix+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'}))
for row in rows:
    if row['source']=='scan' or row['ratio']>1.05:
        print(row)
