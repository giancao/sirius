# PR #2419 review evidence — 2026-11-11

Base `976b4b779956c520ad286df7f57b8e5334c22925`; head `ffa2795b100939a02923c470f035e2adacf16a05`. Both were built independently with the same stable dependencies for SM75 on one RTX 2080. This round changes no repository source, test runner, test expectation, or default resource budget.

## Tests and builds

The current round rebuilt both stable versions and ran the additional stages below. The earlier pre-push results use the same head source and are included in the archive under `pre-push/`; they are not described as freshly rerun here.

| Check                                     | Result                                    | Evidence                                      |
| ----------------------------------------- | ----------------------------------------- | --------------------------------------------- |
| Stable head and base builds               | Pass: library, C++ tests, DuckDB wrapper  | head-stable-build.log / base-stable-build.log |
| CUDA fault                                | 6 passed; 469 assertions                  | stable-fault-late.log                         |
| Late materialization                      | 144 executed; 6 two-GPU early returns     | stable-fault-late.log                         |
| Fused late materialization                | 2 passed; 66 assertions                   | stable-fault-late.log                         |
| Arrow/narrow name filter                  | 162 passed; 115,623 assertions            | stable-arrow-all.log                          |
| Public context                            | Main and head: 2 passed / 3 VRAM failures | base-context.log / stable-extra-stages.log    |
| Earlier ordinary shard                    | 5,494 passed; 1 skip; 1 expected failure  | pre-push/stable-tests.log                     |
| Earlier local S3 gate                     | 92 passed; 84,143 assertions              | pre-push/stable-s3.log                        |
| Earlier formatting / Clang+NVCC / nightly | Passed; nightly compile-only              | pre-push/ build and formatting logs           |

Catch reports 150 late-materialization cases and 7,668 assertions, but six cases return early after a two-GPU warning and do not validate their intended operation. The narrow Arrow-driver filter passed 27 cases / 1,696 assertions and overlaps the 162-case filter; these counts are not added. The earlier FFI cardinality `[!shouldfail]` marker already exists on main and is unchanged; it is not counted as a pass.

The three public-context failures request 7,754,258,841 bytes on an 8 GiB display GPU with about 1 GiB already occupied. Main reproduces the same three source locations and allocation failure. This is an unresolved local hardware limitation, not a passing stage. No memory budget or assertion was weakened.

## Fresh performance measurements

All 48 workloads completed: 288 processes, 2,040 measured samples, 576 warmups. The two extended checks add 12 processes, 240 measured samples and 24 warmups. Every GPU execution matched its independent CPU oracle and showed one GPU execution with zero planning/runtime fallback. Types and row multisets were checked; this timing harness does not verify output ordering.

The four scan workloads use 60 ordinary samples per version, plus a 30-sample same-version control for each version. SF30 uses 10 ordinary samples per version per query plus five-sample controls. The process order is base/head/base-control, then head/base/head-control. Ratios above one mean the head was slower. See [method and reproduction](README.md), [full statistics](comparison.csv), [extended statistics](long-retest-comparison.csv), and individual `paired/` and `long-retest/` directories.

| Workload       | Base median ms | Head median ms | Head/base |
| -------------- | -------------- | -------------- | --------- |
| plain          | 31.704         | 31.714         | 1.000     |
| mapped         | 117.748        | 117.841        | 1.001     |
| partial        | 34.399         | 34.025         | 0.989     |
| mapped_partial | 118.592        | 115.960        | 0.978     |

The mapped fixture uses Iceberg field IDs across INT32 `px/pv` and renamed/promoted INT64 `x/v` files. The partial-pushdown fixture combines a safe range with a null predicate retained after decoding. Mapped files disable reader row filtering, so `mapped_partial` demonstrates mapping plus post-decode filtering, not reader row filtering on mapped files.

| SF30 Q1-Q22 | Median per-query ratio | Ratio of summed query medians |
| ----------- | ---------------------- | ----------------------------- |
| parquet     | 0.999                  | 1.001                         |
| native      | 1.008                  | 1.004                         |

These aggregate figures do not replace per-query inspection. Screening the initial results at a 5% slowdown selected Parquet Q1 and native Q15 for 20 measured repetitions per process (40 ordinary samples per version plus a 20-sample control per version):

| Extended check | Initial ratio | Extended ratio | Round 0 | Round 1 |
| -------------- | ------------- | -------------- | ------- | ------- |
| native q15     | 1.077         | 0.994          | 0.977   | 1.008   |
| parquet q1     | 1.080         | 1.002          | 0.955   | 1.029   |

The initial slowdowns did not persist in the extended samples: Parquet Q1 is 1,090.883 → 1,093.386 ms (1.002), and native Q15 is 217.579 → 216.249 ms (0.994). Both reverse direction between paired rounds. Extended base/head control ratios are 1.002/1.012 for Q1 and 0.975/1.002 for Q15. These measurements do not establish a stable regression in the tested scope; they do not prove zero overhead. All initial measurements remain in the archive.

This is fresh evidence for the current base/head pair. Missing historical raw directories cannot substantiate the older reported ratios; those ratios are not reused here. The scope is local production SQL on SF30 and the four fixtures. It does not establish performance of replacement decoders, direct materializer calls, canonical-lineage first import, or every workload/hardware combination. GPU clocks were not locked, the desktop remained active, and same-version controls show run-to-run variation.

## Remaining validation and publication

- Current-head hosted [Test](https://github.com/sirius-db/sirius/actions/runs/42985345677) and [Check](https://github.com/sirius-db/sirius/actions/runs/42985345681) still report `action_required`; maintainer approval and their results remain pending.
- Public-context validation needs sufficient free VRAM. Two-GPU execution is waived locally by the user; ARM64 is not claimed. Nightly remains compile-only.
- The reviewer's earlier [SF100 L4 measurements](https://github.com/sirius-db/sirius/pull/2419#pullrequestreview-5778517078) are separate evidence on earlier commits, not a local current-head SF100 run.
- The evidence archive contains raw samples, correctness outputs, commands, data recipes and hashes, source/binary fingerprints, failed setup probes, and the earlier pre-push logs. Datasets and compiled binaries are omitted to keep it uploadable.
- The proposed review reply requires user review before posting. No comment was posted and the PR remains Draft.

Final source/binary/input verification is recorded in [final-check.json](final-check.json). The ZIP includes a SHA256 manifest and is read back to verify every archived file.
