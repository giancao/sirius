# Sirius: manual pre-push checks

Run this workflow only when the user explicitly asks to run the Sirius pre-push
checks. A commit, push, rebase or PR request alone does not trigger it. If the user
asks to skip the checks, do not run this workflow. Do not install automatic hooks
or change CI to trigger it.

Apply only to Sirius and its worktrees. Running these checks does not authorize
a commit or push; publication requires the user's separate authorization.
Follow the repository's contribution rules.

## Progress messages

Print progress in the chat so the user can see it, not only in tool output.
Before identifying the base, reviewing, each stable command, Clang + NVCC
configure/build, nightly clean/build, and pushing, print:
`[Sirius pre-push] 开始：<当前动作或命令>`.
After each step, print `通过：<动作>` or `失败：<动作及原因>` with the same prefix.
Announce fixes and retries too. For long steps, give a brief progress update at
least every 60 seconds. If blocked, say that the push has stopped; do not announce
later steps as started or passed.

## Review first

- Review this branch's changes and uncommitted changes intended for the push.
  Use the merge base with the actual PR base: `main` for standalone PRs, the
  parent branch for stacked PRs. Ask if the base is unclear.
- Read inherited code for context, but do not modify it. Report inherited bugs
  that block validation.
- Check correctness, edge cases, lifetimes, concurrency, GPU streams, memory,
  error handling, and fallback behavior where relevant.
- Avoid inefficient work, unnecessary abstractions, overengineering, and invented
  terminology. Prefer existing APIs and simple designs.
- Keep docs/comments accurate, concise, and understandable. Remove repetition,
  vague claims, AI-style filler, and internal plan labels such as "Step 3",
  "Phase 2", or "S4". Keep meaningful instructions, algorithm steps, and identifiers.
- Fix issues within this branch's scope and review the fixes before pre-commit.

## 任务范围与测试流程（test flow）

- 本机显存、内存、GPU 数量、驱动或执行时间限制，不是项目默认行为的需求。
  不得为适应本机或让检查通过，修改 CI 工作流（CI workflows）、测试运行器
  （test runners）、默认并发、分片（shards）、执行阶段、超时、测试筛选、
  标签（tags）、测试夹具（fixtures）资源预算或预期结果。也不要为这类改造
  增加配套调度测试或修改项目使用说明。
- 本机限制只通过已有命令行参数、临时环境变量或仓库外的临时运行安排处理。
  记录实际命令、测试覆盖范围和未运行项；部分或分组运行不能冒充完整默认流程。
  无法完成要求的验证时如实报告，不通过修改项目流程消除失败。
- 测试基础设施（test infrastructure）变更必须属于用户明确要求的任务范围。
  运行 pre-push、遇到本机失败或追求执行方便，不构成扩大范围的授权。
  独立的基础设施问题单独报告，不顺手混入功能 PR。
- 对照实际 PR 基线检查所有改动，特别检查 `.github/workflows/`、`scripts/`、
  `test/scripts/`、运行配置，以及为流程改造添加的测试标签、文档和 `AGENTS.md`
  说明。如果本任务已经引入无关的流程改动，撤回这些改动及其配套内容，保留
  无关的用户工作；不能只恢复默认值却留下整套无关机制。
- 与功能直接相关的语义回归测试（semantic regression tests）、必要的接口适配
  和构建源文件登记仍应保留。按改动目的判断范围，不因文件位于测试目录或
  CMake 清单中就一律删除；不得隐藏必要用例、删除断言或降低测试强度。

## 文档审查（documentation review）

- 逐项判断文档改动是否为本任务所必需，以及是否放在正确文档中。没有构建、
  安装或项目使用方式的相关变化，就不扩写构建文档；本机绕行办法留在本机记录。
  不为满足 PR 清单而机械修改文档，也不把无关代码改动的配套说明一并保留。
- 架构文档（architecture docs）只保留理解当前行为必需的入口、处理顺序、
  职责、所有权（ownership）和限制。合并已有相关段落，避免再写一篇重复说明；
  不把修复历史、审查过程、逐个内部字段、微优化或测试成绩写成产品架构。
  API 细节优先放在接口注释中，文档按需链接。
- 对照实际调用路径核实每项声明，区分默认生产行为、按需能力和仅供调用方使用的
  辅助接口；估算函数不等于已接入自动资源预留（reservation），测试调用不等于
  生产接线。不能把局部保证扩写为所有路径都满足的保证。
- 内存文档（memory docs）保留必要的分配来源、保留期、峰值和调用方预算责任，
  区分持久存储与临时空间、估算与实际预留（reservation），避免重复计费或重复
  扫描实现说明。性能结论必须绑定实际测量范围。
- 按最终实现重新阅读完整上下文，删除过时、重复或无关段落，修正命令和链接。
  用能讲清行为的最短篇幅，不沿用旧修复报告，也不为减少行数删掉必要的使用约束。

## Stable checks

Run separately from the repository root, in this order. Do not skip by file type:

```bash
pixi run pre-commit run -a
pixi run make clean
pixi run make
pixi run make test UNITTEST_ARGS="--steps shards --shards 1"
pixi run make s3-test
```

## Clang + NVCC 构建（build）

这是独立必跑项。GCC 下的 stable/nightly 成功不能代替 Clang + NVCC
组合验证。使用 stable 依赖（dependencies），从仓库根目录执行：

```bash
pixi run make clang-debug
```

从配置日志（configure log）和实际编译命令（compile command）确认：C/C++
使用 Clang，CUDA 使用 NVIDIA NVCC，且 NVCC 的主机编译器（host compiler）
也是 Clang（`-ccbin`）。记录 Clang/NVCC 版本及实际 CUDA 架构（architecture）；
不能把 NVCC + GCC 或仅 Clang C++ 编译算作通过。构建必须覆盖库和 C++ 测试程序
（test executable），不能只编译单个 CUDA 文件。

此项可在 stable 清理前执行；仅在源码（source）、编译器（compiler）、依赖
（dependencies）和构建配置（build configuration）一致时复用结果。每次清理前，
将需要保留的配置、构建和测试日志（logs）存到构建目录（build directory）外。

## Nightly build

After stable and Clang + NVCC checks pass, clean and rebuild with the repository's
cuDF nightly helper. Confirm the command still matches `.github/workflows/check.yml`:

```bash
pixi run make clean
CUDAARCHS=100 pixi run --locked -e nightly-runner nightly-run make release -j"$(nproc)"
```

This checks compatibility with the [nightly CI job](https://github.com/sirius-db/sirius/actions/runs/40087211947/job/120852479885).
It runs on ARM64; local x86 success does not prove ARM64 success. Record resolved
cuDF/RMM/cuVS versions and host architecture. Artifacts now use nightly dependencies;
rebuild before using them with stable dependencies. No nightly runtime tests required.

## Finish

Fix branch-local failures, review changes, and rerun checks for the final source.
Review formatter edits and include only task-related fixes. Preserve unrelated work.
Stop before pushing if checks fail, time out, or cannot run; do not weaken tests.
Ensure reviewed/tested inputs match the outgoing commit, then complete the authorized
push without another confirmation. Report results, limitations, versions, and
branch/commit. Describe the one-shard run accurately, not as the full test suite.
