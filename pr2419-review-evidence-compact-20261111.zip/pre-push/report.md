# PR #2419 rebase、复审及 pre-push 验证

2026-11-11（Asia/Shanghai）。原 PR 提交 `e4c92b3bc29bcf80a44c34d7e5706559cc30c9d8`，原 main 基线 `fed5272eb4a6f1d310cb3b80ea8ef98780667526`。五个提交已重放到 main `976b4b779956c520ad286df7f57b8e5334c22925`；最终提交 `ffa2795b100939a02923c470f035e2adacf16a05`。原提交保留在本地 `codex/backup-pr2419-before-rebase-20261111`。

## 冲突和复审

- `gpu_ingestible.cpp` 合并 main 的 cuCascade scan-stage 类型和 PR 的执行上下文、一次性验证凭据。
- `parquet_scan_core.cpp` 同时保留 main 路径工具和共享解码所需 cuDF helper。
- 后续“撤回测试流程改造”补丁会误删 main 新增的 public-context 阶段及 GPU 探测失败处理，已完整恢复 main 运行器。本 PR 最终不改 CI、脚本、默认并发、阶段、预算、标签或预期结果。
- mapper 改用 Sirius 的 `io/path_utils.hpp`；新增测试改用 cuCascade I/O context，删除读取测试按新接口传共享 context 并移除旧参数。保持 Sirius 路径归一化和 datasource 所有权规则。
- 映射输入身份检查仍先于通用认证，仍归为 `certificate`。归一化 → 可见性 → 剩余条件 → 输出组装顺序、默认 reader 私有完成协议、lineage 的严格导入/区间组合/检查网格/异常退休均保留。

复审与运行回归未发现新的逻辑阻塞项。精确差异见 `range-diff-final.txt`、`outgoing.patch`，源码指纹见 `reviewed-source.json`。更改只包含必要的 rebase/API 适配。

## 执行的检查

按用户指定的 `pre-push-workflow.md` 执行，实际命令和临时环境参数见 `status.json`。

| 检查 | 结果 |
| --- | --- |
| `pixi run pre-commit run -a` | 全仓通过，formatter 修改已复审 |
| `pixi run make clean` + `pixi run make` | stable 全新库、C++ 测试及 DuckDB wrapper 构建通过 |
| `pixi run make test UNITTEST_ARGS="--steps shards --shards 1"` | 5,494 passed、1 硬件 skip、1 main 既有预期失败；44,429,306 assertions；退出 0 |
| `pixi run make s3-test` | 当前集合 92 passed / 84,143 assertions，严格本地 SeaweedFS gate 退出 0 |
| `pixi run make clang-debug` | 库与 C++ 测试程序编译、链接通过 |
| 再次 `pixi run make clean` 后运行 nightly CI helper | nightly release 库与 C++ 测试编译、链接通过，退出 0；未运行 nightly 测试 |

stable 为本机 SM75，cuDF 26.10.02、RMM 26.10.00、cuVS 26.10.00。Clang 22.1.8、NVCC 13.4.92；实际编译命令确认 C/C++ 用 Clang，CUDA 用 NVCC，且 `-ccbin=clang++`，详见 `clang-compiler-proof.json`。宿主是 x86_64。

nightly 使用与 `.github/workflows/check.yml` 相同的 `CUDAARCHS=100 pixi run --locked -e nightly-runner nightly-run make release -j32`（本机 nproc=32）。CMake 架构显式设为 100，构建并行度仅通过临时环境限制。解析版本为 cuDF 26.12.00a566、RMM 26.12.00a32、cuVS 26.12.00a156、NVCC 13.4.92；不把本机成功描述为 ARM64 成功。

单分片实际选中的 5,496 个父用例与日志总数一致，21 个 lineage、25 个 shared-materializer、4 个 mapper 父用例都存在于本轮运行日志，见 `scan-coverage.json`。这里仅执行普通 shards 阶段，**不称为完整默认流程**；public_context、独立 CUDA fault、multi_gpu、late_mat 等其他阶段不在该命令范围。双 GPU 仍按用户原豁免未做本机验证。

main 已有 FFI ranged-scan 估算测试 `[!shouldfail]` 仍为 60,000 对 30,000 的预期失败，源文件、标记和断言未修改；硬件 skip 需要第二张 GPU，未计为通过。

首轮 stable 编译发现新增测试未迁移 `load_delete_payload` 签名，已修复并复审，然后重新进行全仓格式检查、clean/build 和全部上述测试。初始失败日志在 `stable-build-prior-1.log` / `status-before-signature-fix.json`，未覆盖为通过。最终检查均绑定最终提交，见 `final-check.json` 和 `format-source-proof.json`。

## 最后一条 review 及剩余范围

11 月 10 日 review 要求 I/O 迁移冲突、托管 CI 和可复现性能凭据。冲突已解决。本轮开始核对时，旧提交 e4c92b3b 的 Check、Test、Docs、Distribution 都已成功：`pre-rebase-hosted-ci.json`；旧结果不计作新提交的证据。

历史 SF30、mapped/partial-pushdown 报告还在 workshop，但引用的原始测量目录未包含在当前工作区，因此本轮未伪造或声称重新生成这些历史凭据，也未重跑性能基准。reviewer 已另行报告 L4 上的 SF100 A/B 结果；本机无相应 SF100/双 GPU 条件。PR 保持 Draft；正式 Ready 前仍需附历史可复现测量凭据并确认新 head 的托管 CI。本任务没有发布评论或改 PR 审核状态。

## 产物与推送

stable、Clang 的配置、编译命令、日志和二进制指纹在清理前已归档。当前 `build/release` 是 **nightly / SM100** 产物，不能混用 stable 依赖或直接当作本机 RTX 2080 的运行产物；后续运行 stable 需先重建。

推送结果以 `push-result.json` 为准；新 head CI 另存 `post-push-hosted-ci.json`。最终核对未改动与本任务无关的数据和原 `fix/iceberg-table-replacement` 分支。


最终推送成功：`origin/feat-shared-scan-framework-r4b-field` 与本地完整提交一致，工作区干净。GitHub 确认 `mergeable=true`、`draft=true`。新 head 的托管 [Test](https://github.com/sirius-db/sirius/actions/runs/42985345677) 和 [Check](https://github.com/sirius-db/sirius/actions/runs/42985345681)（以及 Docs、Distribution）均为 `action_required`，等待维护者批准，尚未执行；未将其计为通过。
