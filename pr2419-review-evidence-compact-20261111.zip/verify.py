import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--restore-results', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
read = lambda name: json.loads((root/name).read_text())

def path_for(name):
    path = (root/name).resolve()
    assert path.is_relative_to(root), name
    return path

def check(path, info):
    data = path.read_bytes()
    assert len(data) == info['bytes'], str(path)
    assert hashlib.sha256(data).hexdigest() == info['sha256'], str(path)
    return data

manifest = read('SHA256SUMS.json')
for entry in manifest:
    check(path_for(entry['path']), entry)
physical = {entry['path']: entry for entry in manifest}
aliases = {entry['path']: entry for entry in read('result-aliases.json')}
omitted = {entry['path']: entry for entry in read('omitted-files.json')}
for entry in read('FULL-SHA256SUMS.json'):
    name = entry['path']
    assert sum(name in items for items in (physical, aliases, omitted)) == 1, name
    retained = physical.get(name) or aliases.get(name) or omitted[name]
    assert all(retained[key] == entry[key] for key in ('bytes', 'sha256')), name
for name, entry in aliases.items():
    data = check(path_for(entry['canonical']), entry)
    if args.restore_results:
        path = path_for(name)
        if path.exists():
            check(path, entry)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
print(json.dumps(dict(verified_files=len(manifest), result_aliases=len(aliases), omitted_verbose_logs=len(omitted), results_restored=args.restore_results)))
